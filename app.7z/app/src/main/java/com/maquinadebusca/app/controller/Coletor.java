package com.maquinadebusca.app.controller;

import java.net.URL;
import java.util.List;
import java.util.LinkedList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import com.maquinadebusca.app.model.Documento;
import com.maquinadebusca.app.model.service.ColetorService;

@RestController
@RequestMapping("/coletor") // URL: http://localhost:8080/coletor
public class Coletor {
	// URL: http://localhost:8080/coletor/iniciar
	@GetMapping(value = "/iniciar", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public Documento iniciar () {
		ColetorService cs = new ColetorService ();
		Documento doc = cs.iniciar();
		return doc;
	}
}

/*
 * package com.maquinadebusca.app.controller;
 * 
 * 
 * import org.springframework.http.MediaType; import java.io.BufferedReader;
 * import java.io.IOException; import java.io.InputStream; import
 * java.io.InputStreamReader; import java.net.URL; import org.jsoup.Jsoup;
 * import java.net.URLConnection; import org.springframework.http.MediaType;
 * import org.springframework.web.bind.annotation.GetMapping; import
 * org.springframework.web.bind.annotation.RestController; import
 * org.springframework.web.bind.annotation.RequestMapping;
 * 
 * import java.io.BufferedReader; import java.io.IOException; import
 * java.io.InputStream; import java.io.InputStreamReader; import java.net.URL;
 * import java.net.URLConnection; import org.jsoup.Jsoup; import java.util.List;
 * import java.util.LinkedList;
 * 
 * @RestController
 * 
 * @RequestMapping ("/coletor") // URL: http://localhost:8080/coletor public
 * class Coletor { // URL: http://localhost:8080/coletor/iniciar
 * 
 * @GetMapping (value = "/iniciar", produces = MediaType.TEXT_PLAIN_VALUE)
 * public String iniciar () { StringBuilder pagina = new StringBuilder (); try {
 * URL url = new URL
 * ("http://journals.ecs.soton.ac.uk/java/tutorial/networking/urls/readingWriting.html"
 * ); URLConnection url_connection = url.openConnection (); InputStream is =
 * url_connection.getInputStream (); InputStreamReader reader = new
 * InputStreamReader (is); BufferedReader buffer = new BufferedReader (reader);
 * String linha; while ((linha = buffer.readLine ()) != null) { pagina.append
 * (linha); } } catch (IOException e) { pagina.append
 * ("Erro: não foi possível coletar a página."); } return pagina.toString (); }
 * }
 */